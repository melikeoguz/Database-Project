
public class KimyasalMaddeAdlari {
    
    private String kimyasalAdi;

    public KimyasalMaddeAdlari(String kimyasalAdi) {
        this.kimyasalAdi = kimyasalAdi;
    }

    public String getKimyasalAdi() {
        return kimyasalAdi;
    }

    public void setKimyasalAdi(String kimyasalAdi) {
        this.kimyasalAdi = kimyasalAdi;
    }
    
    
    
    
}
