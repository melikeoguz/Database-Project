
public class Database {
    public static final String kullanici_adi = "root";
    public static final String parola = "";
    public static final String db_ismi = "ocrproject";
    public static final String host = "localhost";
    public static final int port = 3306;  
    
}

